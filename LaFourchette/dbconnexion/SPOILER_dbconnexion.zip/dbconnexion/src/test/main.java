/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import entites.personne;
import services.personneservice;

import utils.mydb;

/**
 *
 * @author ridha
 */
public class main {
    public static void main(String[] args) {
        
        personneservice sp = new personneservice() ;
        personne aj = new personne(2, "kdkdkd", "fhqhq", 4475155);
        sp.ajouter(aj);
        sp.find();
        
        
    }
    
        
    
    
   
    
}
